var game = {}
	game.initial = function()
	{
		this.oknum = document.getElementById("oknum");
	    this.oknumShow = document.getElementById("oknumShow");
	    this.shadowBox = document.getElementById("shadowBox");
	    this.startBtn = document.getElementById("startBtn");
	    this.stopBtn = document.getElementById("stopBtn");
	   this.num = num;
	    
		for(var i = 1;i <= 100;i++)
		{
		  alldata.push(i);
		}
		 num = alldata.length-1 ; 
	}
	game.change = function()
	{ 
		oknum.innerHTML = alldata[game.GetRnd(0,num)]; 
	} 
	game.start = function()
	{
		clearInterval(timer); 
		timer = setInterval( game.change,50); 
		oknumShow.style.top = "438px";
		shadowBox.style.display = "none";
		startBtn.style.display = "none";
		stopBtn.style.display = "block";
		oknumShow.style.visibility = "hidden";
		oknum.style.display = "block";
	}

	game.ok = function()
	{
		clearInterval(timer); 
		oknumShow.innerHTML = oknum.innerText;
	    function  screening()
	    {
			for(var j = 0;j <= alldata.length; j++)
			{
				if(alldata[j] == oknum.innerText)
				{
					return j;	
				}
			};
		}		 
		alldata.splice(screening(),1);
		num = alldata.length-1 ;
		//console.log(alldata);
		oknum.style.display = "none";
		shadowBox.style.display = "block";
		startBtn.style.display = "block";
		stopBtn.style.display = "none";
		oknumShow.style.visibility = "visible";		
		game.startMove(oknumShow,{top:240},{type:'buffer'});
	}
	game.GetRnd = function(min,max)
	{
		return parseInt(Math.random()*(max-min+1)); 
	}
	game.startMove = function(obj, json, options)
	{
		options = options || {};
		options.time = options.time||700;
		options.type = options.type||'buffer';	
		var count = parseInt(options.time/30);
		var n = 0;		
		var start = {};
		var dis = {};		
		for(var i in json)
		{
			if( i == 'opacity' )
			{
				start[i] = parseFloat(game.getStyle(obj, i))*100;
			}
			else
			{
				start[i] = parseInt(game.getStyle(obj, i));
			}
			
			if( isNaN(start[i]) )
			{
				switch(i)
				{
					case 'left':
						start[i]=obj.offsetLeft;
						break;
					case 'top':
						start[i]=obj.offsetTop;
						break;
					case 'width':
						start[i]=obj.offsetWidth;
						break;
					case 'height':
						start[i]=obj.offsetHeight;
						break;
				}
			}	

			dis[i] = json[i] - start[i];
			
		}
		
		clearInterval(obj.timer);
		obj.timer = setInterval(function (){
			n++;		
			for(var i in json)
			{
				switch(options.type)
				{
					case 'linear':
						//匀速
						var a = n/count;	//0-1
						break;
					case 'buffer':
						var a = 1-n/count;
						a = (1-a*a*a);
						break;
				}
				
				var cur=start[i]+dis[i]*a;
				
				if( i == 'opacity' )
				{
					obj.style.filter ='alpha(opacity:' + cur + ')';
					obj.style.opacity = cur/100;
				}
				else
				{
					obj.style[i] = cur+'px';
				}
			}
			
			if(n == count)
			{
				clearInterval(obj.timer);
			}
		}, 30);
	}
    game.getStyle = function(obj, name)
    {
    	return (obj.currentStyle || getComputedStyle(obj, false))[name];
    }